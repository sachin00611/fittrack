# FitTrack AI

A centralized backend that securely manages user authentication and workout records through RESTful APIs,
and uses **Google Gemini AI** to analyze workout statistics and give personalized recommendations.
Includes a simple frontend served by Express.

**Stack:** Node.js, Express.js, MongoDB (Mongoose), JWT, bcrypt, Google Gemini API, Postman, npm.

## Setup

1. Install [Node.js 18+](https://nodejs.org) and MongoDB (local) or use a free [MongoDB Atlas](https://www.mongodb.com/atlas) cluster.
2. Get a free Gemini API key at https://aistudio.google.com/apikey
3. In this folder:

```bash
npm install
cp .env.example .env      # Windows: copy .env.example .env
# edit .env -> set MONGO_URI, JWT_SECRET, GEMINI_API_KEY
npm start                 # or: npm run dev
```

4. Open http://localhost:5000 for the frontend.
5. Import `postman/FitTrackAI.postman_collection.json` in Postman to test the API.
   Run **Register** or **Login** first; the token is stored automatically.

## API Endpoints

| Method | Endpoint | Auth | Description |
|---|---|---|---|
| POST | /api/auth/register | No | Create account, returns JWT |
| POST | /api/auth/login | No | Login, returns JWT |
| GET | /api/auth/me | Yes | Current user profile |
| PUT | /api/auth/me | Yes | Update name/goal/age/weight/height |
| POST | /api/workouts | Yes | Create workout |
| GET | /api/workouts | Yes | List (filters: type, from, to, page, limit) |
| GET | /api/workouts/stats?days=30 | Yes | Aggregated stats |
| GET | /api/workouts/:id | Yes | Get one workout |
| PUT | /api/workouts/:id | Yes | Update workout |
| DELETE | /api/workouts/:id | Yes | Delete workout |
| GET | /api/ai/insights | Yes | Gemini analysis of last 30 days |
| POST | /api/ai/recommendations | Yes | Gemini personalized weekly plan |
| GET | /api/health | No | Health check |

Send the token as `Authorization: Bearer <token>`.

## Security notes
- Passwords hashed with bcrypt; never returned in responses.
- JWT-protected routes; every workout query is scoped to the logged-in user.
- helmet, CORS, and rate limiting enabled. Keep `.env` private (it is git-ignored).
- The Gemini key stays on the server and is never exposed to the browser.

## Project structure
```
fittrack-ai/
├── server.js
├── src/
│   ├── config/db.js
│   ├── models/        User.js, Workout.js
│   ├── middleware/    auth.js, errorHandler.js
│   ├── routes/        auth.js, workouts.js, ai.js
│   └── services/      stats.js, gemini.js
├── public/            index.html, style.css, app.js  (frontend)
└── postman/           FitTrackAI.postman_collection.json
```
