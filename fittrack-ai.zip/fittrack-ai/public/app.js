const API = '/api';
const $ = (id) => document.getElementById(id);
let token = localStorage.getItem('ft_token');

async function api(path, options = {}) {
  const res = await fetch(API + path, {
    ...options,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: 'Bearer ' + token } : {}),
      ...(options.headers || {})
    }
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    if (res.status === 401 && token) logout();
    throw new Error(data.message || 'Request failed');
  }
  return data;
}

const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const setMsg = (el, text, ok = false) => { el.textContent = text; el.className = 'msg' + (ok ? ' ok' : ''); };

/* ---------- View switching ---------- */
function showAuth() {
  $('authView').classList.remove('hidden');
  $('dashView').classList.add('hidden');
  $('userBox').classList.add('hidden');
}
async function showDashboard() {
  $('authView').classList.add('hidden');
  $('dashView').classList.remove('hidden');
  $('userBox').classList.remove('hidden');
  try {
    const { user } = await api('/auth/me');
    $('userName').textContent = user.name;
  } catch { return; }
  await refresh();
}
function logout() {
  token = null;
  localStorage.removeItem('ft_token');
  showAuth();
}

/* ---------- Auth ---------- */
$('tabLogin').onclick = () => toggleTab(true);
$('tabRegister').onclick = () => toggleTab(false);
function toggleTab(login) {
  $('loginForm').classList.toggle('hidden', !login);
  $('registerForm').classList.toggle('hidden', login);
  $('tabLogin').classList.toggle('active', login);
  $('tabRegister').classList.toggle('active', !login);
  setMsg($('authMsg'), '');
}

async function handleAuth(path, body) {
  try {
    const data = await api(path, { method: 'POST', body: JSON.stringify(body) });
    token = data.token;
    localStorage.setItem('ft_token', token);
    showDashboard();
  } catch (err) { setMsg($('authMsg'), err.message); }
}

$('loginForm').onsubmit = (e) => {
  e.preventDefault();
  handleAuth('/auth/login', { email: $('loginEmail').value, password: $('loginPassword').value });
};
$('registerForm').onsubmit = (e) => {
  e.preventDefault();
  const num = (id) => ($(id).value ? Number($(id).value) : undefined);
  handleAuth('/auth/register', {
    name: $('regName').value, email: $('regEmail').value, password: $('regPassword').value,
    goal: $('regGoal').value, age: num('regAge'), weightKg: num('regWeight'), heightCm: num('regHeight')
  });
};
$('logoutBtn').onclick = logout;

/* ---------- Workouts ---------- */
async function refresh() {
  await Promise.all([loadStats(), loadWorkouts()]);
}

async function loadStats() {
  const s = await api('/workouts/stats?days=30');
  $('statsBox').innerHTML = `
    <div class="stat"><b>${s.totalWorkouts}</b><span>Workouts (30d)</span></div>
    <div class="stat"><b>${s.totalMinutes}</b><span>Minutes</span></div>
    <div class="stat"><b>${s.totalCalories}</b><span>Calories</span></div>
    <div class="stat"><b>${s.workoutsPerWeek}</b><span>Per week</span></div>`;
}

async function loadWorkouts() {
  const { workouts } = await api('/workouts?limit=50');
  $('workoutList').innerHTML = workouts.length
    ? workouts.map((w) => `
      <li>
        <div>
          <strong>${esc(w.title)}</strong><span class="tag">${esc(w.type)}</span>
          <small>${new Date(w.date).toLocaleDateString()} · ${w.durationMinutes} min · ${w.caloriesBurned || 0} kcal</small>
        </div>
        <button class="del" data-id="${w._id}" title="Delete">✕</button>
      </li>`).join('')
    : '<li>No workouts yet. Log your first one!</li>';
}

$('workoutList').onclick = async (e) => {
  const id = e.target.dataset.id;
  if (!id || !confirm('Delete this workout?')) return;
  await api('/workouts/' + id, { method: 'DELETE' });
  refresh();
};

$('workoutForm').onsubmit = async (e) => {
  e.preventDefault();
  const body = {
    title: $('wTitle').value, type: $('wType').value,
    durationMinutes: Number($('wDuration').value),
    caloriesBurned: Number($('wCalories').value) || 0,
    notes: $('wNotes').value
  };
  if ($('wDate').value) body.date = $('wDate').value;
  try {
    await api('/workouts', { method: 'POST', body: JSON.stringify(body) });
    e.target.reset();
    setMsg($('workoutMsg'), 'Workout added!', true);
    refresh();
  } catch (err) { setMsg($('workoutMsg'), err.message); }
};

/* ---------- AI ---------- */
async function runAI(btn, fn) {
  const out = $('aiOutput');
  btn.disabled = true;
  out.textContent = 'Gemini is thinking…';
  try { out.textContent = await fn(); }
  catch (err) { out.textContent = '⚠ ' + err.message; }
  btn.disabled = false;
}

$('insightsBtn').onclick = () =>
  runAI($('insightsBtn'), async () => (await api('/ai/insights')).insights);

$('planBtn').onclick = () =>
  runAI($('planBtn'), async () =>
    (await api('/ai/recommendations', {
      method: 'POST',
      body: JSON.stringify({ daysAvailable: Number($('aiDays').value), equipment: $('aiEquip').value })
    })).recommendation);

/* ---------- Init ---------- */
token ? showDashboard() : showAuth();
