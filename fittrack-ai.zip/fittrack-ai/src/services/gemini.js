// Calls the Google Gemini REST API directly (Node 18+ built-in fetch, no extra SDK needed).
const MODEL = () => process.env.GEMINI_MODEL || 'gemini-2.5-flash';

exports.askGemini = async function askGemini(prompt) {
  const key = process.env.GEMINI_API_KEY;
  if (!key || key === 'your_gemini_api_key_here') {
    const err = new Error('GEMINI_API_KEY is not configured on the server');
    err.status = 503;
    throw err;
  }

  const url = `https://generativelanguage.googleapis.com/v1beta/models/${MODEL()}:generateContent`;
  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-goog-api-key': key },
    body: JSON.stringify({
      contents: [{ role: 'user', parts: [{ text: prompt }] }],
      generationConfig: { temperature: 0.7, maxOutputTokens: 1500 }
    })
  });

  const data = await res.json().catch(() => ({}));
  if (!res.ok) {
    const err = new Error(data?.error?.message || 'Gemini API request failed');
    err.status = res.status === 429 ? 429 : 502;
    throw err;
  }

  const text = data?.candidates?.[0]?.content?.parts?.map((p) => p.text).join('') || '';
  if (!text) {
    const err = new Error('Gemini returned an empty response');
    err.status = 502;
    throw err;
  }
  return text;
};
