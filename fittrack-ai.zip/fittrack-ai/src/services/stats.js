const Workout = require('../models/Workout');

// Aggregates a user's workout history for the last N days.
exports.getStats = async function getStats(userId, days = 30) {
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
  const workouts = await Workout.find({ user: userId, date: { $gte: since } }).sort({ date: -1 });

  const byType = {};
  let totalMinutes = 0;
  let totalCalories = 0;

  workouts.forEach((w) => {
    totalMinutes += w.durationMinutes;
    totalCalories += w.caloriesBurned || 0;
    byType[w.type] = byType[w.type] || { count: 0, minutes: 0 };
    byType[w.type].count += 1;
    byType[w.type].minutes += w.durationMinutes;
  });

  const activeDays = new Set(workouts.map((w) => w.date.toISOString().slice(0, 10))).size;

  return {
    periodDays: days,
    totalWorkouts: workouts.length,
    totalMinutes,
    totalCalories,
    activeDays,
    avgMinutesPerWorkout: workouts.length ? Math.round(totalMinutes / workouts.length) : 0,
    workoutsPerWeek: +(workouts.length / (days / 7)).toFixed(1),
    byType,
    recent: workouts.slice(0, 10).map((w) => ({
      title: w.title, type: w.type, durationMinutes: w.durationMinutes,
      caloriesBurned: w.caloriesBurned, date: w.date.toISOString().slice(0, 10),
      exercises: w.exercises
    }))
  };
};
