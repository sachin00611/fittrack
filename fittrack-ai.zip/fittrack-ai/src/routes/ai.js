const express = require('express');
const protect = require('../middleware/auth');
const { getStats } = require('../services/stats');
const { askGemini } = require('../services/gemini');

const router = express.Router();
router.use(protect);

const profileText = (u) =>
  `Name: ${u.name}; Goal: ${u.goal}; Age: ${u.age ?? 'n/a'}; Weight: ${u.weightKg ?? 'n/a'} kg; Height: ${u.heightCm ?? 'n/a'} cm`;

const SAFETY =
  'You are a supportive fitness coach. Be practical and concise, use short sections and bullet points. ' +
  'You are not a doctor: add a one-line reminder to consult a professional for medical concerns or injuries.';

// GET /api/ai/insights  -> analysis of recent workout stats
router.get('/insights', async (req, res, next) => {
  try {
    const stats = await getStats(req.user._id, 30);
    if (stats.totalWorkouts === 0) {
      return res.status(400).json({ message: 'Log at least one workout to get insights' });
    }
    const prompt = `${SAFETY}

User profile: ${profileText(req.user)}
Workout statistics (last 30 days), JSON:
${JSON.stringify(stats, null, 2)}

Analyze this data. Give: 1) a short summary of consistency and volume, 2) strengths, 3) gaps or imbalances (e.g. too little strength or recovery), 4) three specific, actionable tips.`;
    const insights = await askGemini(prompt);
    res.json({ stats, insights });
  } catch (err) { next(err); }
});

// POST /api/ai/recommendations  body: { daysAvailable?, minutesPerSession?, equipment?, focus? }
router.post('/recommendations', async (req, res, next) => {
  try {
    const { daysAvailable = 4, minutesPerSession = 45, equipment = 'bodyweight only', focus = '' } = req.body || {};
    const stats = await getStats(req.user._id, 30);

    const prompt = `${SAFETY}

User profile: ${profileText(req.user)}
Recent activity (last 30 days), JSON:
${JSON.stringify(stats, null, 2)}

Constraints: ${daysAvailable} days/week, ${minutesPerSession} minutes per session, equipment: ${equipment}. ${focus ? 'Focus area: ' + focus + '.' : ''}

Create a personalized 1-week workout plan that matches the goal and builds on what they already do.
For each day list exercises with sets x reps (or duration), plus one line on why. Include a rest/recovery note.`;
    const recommendation = await askGemini(prompt);
    res.json({ recommendation });
  } catch (err) { next(err); }
});

module.exports = router;
