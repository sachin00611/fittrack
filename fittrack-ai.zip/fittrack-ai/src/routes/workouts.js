const express = require('express');
const Workout = require('../models/Workout');
const protect = require('../middleware/auth');
const { getStats } = require('../services/stats');

const router = express.Router();
router.use(protect);

const FIELDS = ['title', 'type', 'durationMinutes', 'caloriesBurned', 'exercises', 'notes', 'date'];
const pick = (body) => FIELDS.reduce((o, k) => (body[k] !== undefined ? { ...o, [k]: body[k] } : o), {});

// GET /api/workouts?type=cardio&from=2025-01-01&to=2025-01-31&page=1&limit=20
router.get('/', async (req, res, next) => {
  try {
    const { type, from, to } = req.query;
    const page = Math.max(parseInt(req.query.page) || 1, 1);
    const limit = Math.min(parseInt(req.query.limit) || 20, 100);

    const filter = { user: req.user._id };
    if (type) filter.type = type;
    if (from || to) {
      filter.date = {};
      if (from) filter.date.$gte = new Date(from);
      if (to) filter.date.$lte = new Date(to);
    }

    const [items, total] = await Promise.all([
      Workout.find(filter).sort({ date: -1 }).skip((page - 1) * limit).limit(limit),
      Workout.countDocuments(filter)
    ]);
    res.json({ total, page, pages: Math.ceil(total / limit), workouts: items });
  } catch (err) { next(err); }
});

// GET /api/workouts/stats?days=30
router.get('/stats', async (req, res, next) => {
  try {
    const days = Math.min(parseInt(req.query.days) || 30, 365);
    res.json(await getStats(req.user._id, days));
  } catch (err) { next(err); }
});

// POST /api/workouts
router.post('/', async (req, res, next) => {
  try {
    const workout = await Workout.create({ ...pick(req.body), user: req.user._id });
    res.status(201).json({ workout });
  } catch (err) { next(err); }
});

// GET /api/workouts/:id
router.get('/:id', async (req, res, next) => {
  try {
    const workout = await Workout.findOne({ _id: req.params.id, user: req.user._id });
    if (!workout) return res.status(404).json({ message: 'Workout not found' });
    res.json({ workout });
  } catch (err) { next(err); }
});

// PUT /api/workouts/:id
router.put('/:id', async (req, res, next) => {
  try {
    const workout = await Workout.findOneAndUpdate(
      { _id: req.params.id, user: req.user._id },
      pick(req.body),
      { new: true, runValidators: true }
    );
    if (!workout) return res.status(404).json({ message: 'Workout not found' });
    res.json({ workout });
  } catch (err) { next(err); }
});

// DELETE /api/workouts/:id
router.delete('/:id', async (req, res, next) => {
  try {
    const workout = await Workout.findOneAndDelete({ _id: req.params.id, user: req.user._id });
    if (!workout) return res.status(404).json({ message: 'Workout not found' });
    res.json({ message: 'Workout deleted' });
  } catch (err) { next(err); }
});

module.exports = router;
