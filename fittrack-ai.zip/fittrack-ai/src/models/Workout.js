const mongoose = require('mongoose');

const exerciseSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    sets: { type: Number, min: 0 },
    reps: { type: Number, min: 0 },
    weightKg: { type: Number, min: 0 }
  },
  { _id: false }
);

const workoutSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, required: true, trim: true, maxlength: 100 },
    type: { type: String, enum: ['strength', 'cardio', 'hiit', 'yoga', 'flexibility', 'sports', 'other'], default: 'other' },
    durationMinutes: { type: Number, required: true, min: 1, max: 600 },
    caloriesBurned: { type: Number, min: 0, default: 0 },
    exercises: { type: [exerciseSchema], default: [] },
    notes: { type: String, maxlength: 500 },
    date: { type: Date, default: Date.now, index: true }
  },
  { timestamps: true }
);

module.exports = mongoose.model('Workout', workoutSchema);
