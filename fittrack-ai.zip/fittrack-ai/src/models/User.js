const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true, maxlength: 60 },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    password: { type: String, required: true, minlength: 6, select: false },
    // Optional profile data that helps the AI personalize advice
    goal: { type: String, enum: ['lose_weight', 'build_muscle', 'endurance', 'general_fitness'], default: 'general_fitness' },
    age: { type: Number, min: 10, max: 100 },
    weightKg: { type: Number, min: 20, max: 300 },
    heightCm: { type: Number, min: 80, max: 250 }
  },
  { timestamps: true }
);

userSchema.pre('save', async function (next) {
  if (!this.isModified('password')) return next();
  this.password = await bcrypt.hash(this.password, 10);
  next();
});

userSchema.methods.matchPassword = function (plain) {
  return bcrypt.compare(plain, this.password);
};

module.exports = mongoose.model('User', userSchema);
